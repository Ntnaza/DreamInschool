globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/855f3fadc057864d.js",
    "static/chunks/b2fb77facc3c4fd6.js",
    "static/chunks/30ea11065999f7ac.js",
    "static/chunks/77546527a2542547.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-7d318507da537a3d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];